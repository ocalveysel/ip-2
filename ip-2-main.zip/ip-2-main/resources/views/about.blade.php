@extends('layout')

@section('main')
    Hakkımızda Sayfasının İçeriği
@endsection

@section('bottom-message')
    1990'dan Beri
@endsection
