@extends('layout')

@section('main')
    Ana Sayfa İçeriği
@endsection
