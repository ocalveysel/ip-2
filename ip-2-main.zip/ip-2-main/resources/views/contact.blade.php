@extends('layout')

@section('main')
    İletişim Sayfası İçeriği
@endsection
